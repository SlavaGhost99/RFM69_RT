# RFM69_RT
0 uS - 130 uS Подготовка и установка ModeIdle  (Fig01.png)
![Fig01](https://user-images.githubusercontent.com/60197420/149631178-95326b16-255a-4ec7-ac9d-d12374cb2e40.png)

390 uS - 760 uS Запись и отправка первой части пакета (Fig02.png)
![Fig02](https://user-images.githubusercontent.com/60197420/149631195-8683bb8e-962b-49a4-af05-6e58de65b2d5.png)

21 mS: 610 uS - 21 mS: 710 uS Запись и отправка следующей части пакета (Fig03.png)
![Fig03](https://user-images.githubusercontent.com/60197420/149631202-a32cc0fb-fd75-4934-8f2d-ea001cc4595b.png)

50 mS : 280 uS - 50 mS: 320 uS Запись и отправка последней части пакета

50 mS : 725 uS - 51 mS: 670 uS Завершение отправки , переключение в ModeRX (Fig04.png)
![Fig04](https://user-images.githubusercontent.com/60197420/149631208-a61dabea-2b19-41f9-a51b-a56b15fe2247.png)

98 mS : 990 uS - 99 mS: 215 uS Прием ACK (Fig05.png)
![Fig05](https://user-images.githubusercontent.com/60197420/149631210-2d1ed068-fd58-4de7-8317-42729a432b02.png)


0 uS - 130 uS Preparing and setting ModeIdle  (Fig01.png)
![Fig01](https://user-images.githubusercontent.com/60197420/149631185-0086572c-120e-455d-bb11-637632aa60dd.png)

390 uS - 760 uS Write and send the first part of the packet (Fig02.png)
![Fig02](https://user-images.githubusercontent.com/60197420/149631214-f322357d-83e8-4ceb-8626-cdb6b45392f3.png)

21 mS: 610 uS - 21 mS: 710 uS Write and send the next part of the packet (Fig03.png)
![Fig03](https://user-images.githubusercontent.com/60197420/149631218-ab21dc3e-e926-4fb6-b416-e95583c028cf.png)

50 mS : 280 uS - 50 mS : 320 uS Write and send the last part of the packet

50 mS : 725 uS - 51 mS : 670 uS Send complete, switch to ModeRX (Fig04.png)
![Fig04](https://user-images.githubusercontent.com/60197420/149631223-cd43ac05-da4f-4e17-9f1d-b3980ce52d2e.png)

98 mS : 990 uS - 99 mS : 215 uS Receive ACK (Fig05.png)
![Fig05](https://user-images.githubusercontent.com/60197420/149631239-a3171714-e45c-491d-83ea-ca47c6b4d3dd.png)


![Full](https://user-images.githubusercontent.com/60197420/149631245-e0d6d5b5-5f00-4e88-b60c-446a6483bc68.png)

