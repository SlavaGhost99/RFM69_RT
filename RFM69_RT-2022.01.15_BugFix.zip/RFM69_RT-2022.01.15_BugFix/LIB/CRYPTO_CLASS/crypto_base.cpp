// Header: 
// File Name: crypto_base.cpp
// Author: 
// Date: 

/******************************************************************************/
#include "main.h"
#include "crypto_base.h"
//Start File
Crypto_base::Crypto_base()
{
}








//End File
